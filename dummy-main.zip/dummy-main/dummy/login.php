<?php
session_start();

// Replace these with your actual database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare SQL query to check credentials
    $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Success: User found
        $_SESSION['username'] = $username;
        header("Location: dashboard.php"); // Redirect to a dashboard page
    } else {
        // Failure: Invalid credentials
        echo "<p>Invalid username or password</p>";
    }

    $stmt->close();
}
$conn->close();
?>
